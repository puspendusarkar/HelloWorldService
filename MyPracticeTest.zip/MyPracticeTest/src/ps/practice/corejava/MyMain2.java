package ps.practice.corejava;

import java.util.*;

public class MyMain2 {
    public static void main(String[] args){
        reverserword();
        balanceString();

    }

    public static void reverserword() {
        StringBuffer stringBuffer=new StringBuffer();
        List<String> listStr=new ArrayList<String>();
        Character[] characters = {'a', 'b', 'c', ' ', 'x', 'y', 'z'};
        for( Character ch:characters){
            System.out.println(ch);
            if(!ch.equals(' ')){
                stringBuffer.append(ch);
                System.out.println(stringBuffer);
            }
            else{
                listStr.add(stringBuffer.toString());
                stringBuffer.setLength(0);
            }
        }
        listStr.add(stringBuffer.toString());
        System.out.println(listStr);
        stringBuffer.setLength(0);
        for(int i=listStr.size()-1;i>=0;i--){
            stringBuffer.append(listStr.get(i)+" ");
        }
        System.out.println(stringBuffer.toString());
        String[] rvChar=stringBuffer.toString().split("");
        for(String s:rvChar){
            System.out.println(s);
        }
    }
    public static void balanceString(){
        String unblancedString="{[()]}{}}](";
        Stack<String> charactersStack=new Stack<String>();
        Map<String,String> parenthesis=new HashMap<String,String>();
        parenthesis.put("]","[");
        parenthesis.put("}","{");
        parenthesis.put(")","(");
        String[] strings=unblancedString.split("");
        for(String s:strings){
            if(charactersStack.isEmpty()){
                charactersStack.push(s);
            }
            else
                if(parenthesis.containsKey(s) && charactersStack.peek().equalsIgnoreCase(parenthesis.get(s)) ){
                    charactersStack.pop();
                }
                else {
                    charactersStack.push(s);
                }
        }

        System.out.println(charactersStack.size());
        for(String s:charactersStack){
            if(parenthesis.containsKey(s))
            {
            System.out.println("key"+parenthesis.get(s));
            }
            else {
                parenthesis.forEach((k,v)->{
                    if(s.equalsIgnoreCase(v)){
                        System.out.println("Value"+k);
                    }
                });
            }
        }

    }

}
