package ps.practice.corejava;

import java.lang.reflect.Array;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class MyMain {
    public static void main(String[] args){
        System.out.println("test");
        System.out.println(reverseString("sarkar"));
        maxProfitinStocks();
        findDuplicateCharString();
        logSubStr();
        groupingEmploy();
        getOccerenceChar();
        checkValidParenthesis();
        cehckAutomorphic();
    }

    public static String reverseString(String actualString){
        StringBuffer stringBuffer=new StringBuffer(actualString.length());
        char[] chars=actualString.toCharArray();
        for(int i=actualString.length()-1;i>=0;i--){
            stringBuffer.append(chars[i]);
        }
        return stringBuffer.toString();
    }
    // max profit from stock price array
    //input-array of stock price -[10,4,6,8,7,9]
    //output-5
    public static void maxProfitinStocks(){
        int mxdiff=0;
        int[] ints={1,7,5,3,6,4,17};
        for(int i=0;i<ints.length;i++){
            for(int j=i;j<ints.length;j++){
                if((ints[j]-ints[i])>mxdiff){
                    mxdiff=ints[j]-ints[i];
                }
            }
        }
        System.out.println(mxdiff);
    }
    //find duplicate char in a string
    //input -puspendu
    //output-p,u
    public static void findDuplicateCharString(){
        char[] charsName="puspendup".toCharArray();
        ArrayList<Character> arrayListname=new ArrayList<Character>();
        for(int i=0;i<charsName.length;i++){
            for(int j=i+1;j<charsName.length;j++){
                if(charsName[i]==charsName[j]){
                    System.out.println("Duplicate: "+ charsName[j]);
                    if(!arrayListname.contains(charsName[j]))
                    arrayListname.add(charsName[j]);
                    break;
                }
            }
        }
        System.out.println(arrayListname);

    }
    //longest substring in a string
    //input-"abcabcbb"
    //output-abc
    public static void logSubStr(){
        char[] charsInputStr="abcabcbb".toCharArray();
        List<Character> characterList=new ArrayList<Character>();
        characterList.add(charsInputStr[0]);
        StringBuffer stringBuffer=new StringBuffer();
        stringBuffer.append(charsInputStr[0]);

        for(int i=1;i<charsInputStr.length;i++){
            for(int j=0;j<characterList.size();j++){
                if(charsInputStr[i]==characterList.get(j)){
                    break;
                }
            }
            characterList.add(charsInputStr[i]);
            //stringBuffer.append(charsInputStr[i]);

        }
        System.out.println(characterList);
    }

    public static List<Employ> getEmployList(){
        List<Employ> employList=new ArrayList<Employ>();
        Employ employ1=new Employ("Puspendu","Sarkar","IT");
        Employ employ2=new Employ("Bidhan","Mondal","MK");
        Employ employ3=new Employ("Gourik","Ghosh","IT");
        Employ employ4=new Employ("Pinaki","Sarkar","TT");
        Employ employ5=new Employ("Joydeep","Mukherjee","MK");
        employList.add(employ1);
        employList.add(employ2);
        employList.add(employ3);
        employList.add(employ4);
        employList.add(employ5);
        return employList;

    }
    public static void groupingEmploy(){
        List<Employ> employList=getEmployList();
        Map<String,List<Employ>> listMap=employList.stream().collect(Collectors.groupingBy(Employ::getDeptCode));
        Map<String,List<Employ>> listMap1=employList.stream().collect(Collectors.groupingBy(Employ::getLastname));
        System.out.println(listMap);
        System.out.println(listMap1);
    }

    //find nubber of occurence each char
//input- puspendu
//output- p->2, u->2, s->1, e->1,n->1,d->1
    public static void getOccerenceChar(){
        String[] stringsAr="puspendu".split("");
        List<String> stringList=Arrays.asList(stringsAr);
        Map<String,Long> integerMap=stringList.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
        System.out.println(integerMap);

    }
 //valid parenthesis
 //input -[{()}()]
 //valid
 //input- {({)}
 public static void checkValidParenthesis(){
        //char[] charsAr="[{()}()]".toCharArray();
     String[] charArr="[{()}]".split("");
     Stack<String> stackParenthesis=new Stack<String>();
     Map<String,String> parenthesis=new HashMap<String,String>();
     parenthesis.put("]","[");
     parenthesis.put("}","{");
     parenthesis.put(")","(");
     for(String c:charArr){
         if(stackParenthesis.isEmpty()){
             stackParenthesis.push(c);
             System.out.println("1" +stackParenthesis);

         }
         else {
             if(stackParenthesis.peek().equalsIgnoreCase(parenthesis.get(c))){
                 System.out.println("2" +stackParenthesis);
                 stackParenthesis.pop();
                 System.out.println("3" +stackParenthesis);
             }
             else{
                 System.out.println("4" +stackParenthesis);
                 stackParenthesis.push(c);
                 System.out.println("5" +stackParenthesis);
             }
         }
     }
     if(stackParenthesis.isEmpty()){
         System.out.println("Valid" +stackParenthesis);
     }
     else
     {
         System.out.println("invalid" +stackParenthesis);
     }
 }

 //check automorphic number
    //5 - 5*5-25
    //25- 25*25-625

    public static void cehckAutomorphic(){
        Integer inputnumber, squareInt,temp,sqrten;
        int count=0;
        inputnumber=76;
         squareInt=inputnumber*inputnumber;
        temp=squareInt;
                while (temp>0){
            count++;
            temp=temp/10;

        }
                sqrten=10;
        System.out.println("count"+count);
        for(int i=1;i<count-1;i++){
            sqrten=sqrten*sqrten;
        }
        System.out.println("sqrten"+sqrten);
        if(inputnumber == squareInt % sqrten){
            System.out.println("automorphic number");
        }

    }

}
