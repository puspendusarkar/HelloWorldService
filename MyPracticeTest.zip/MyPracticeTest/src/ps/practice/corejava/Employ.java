package ps.practice.corejava;

public class Employ {
    private String firstName;
    private  String lastname;
    private String deptCode;

    public Employ(String firstName, String lastname, String deptCode) {
        this.firstName = firstName;
        this.lastname = lastname;
        this.deptCode = deptCode;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }
}
